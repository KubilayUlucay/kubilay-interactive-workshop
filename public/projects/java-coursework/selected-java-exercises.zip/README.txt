Selected CS105 Java coursework

Source: Kubilay Ulucay's authored-work folder; course exercise specifications retain their attribution.
The 13 Java files are preserved unchanged. Source reviewed statically here, not newly compiled or executed.

Homework1/Q1.java: shipment-weight branches. The final else is attached only to the last if; lower weights can print both a rate and a rejection. This original behavior is not corrected.
Homework1/Q2.java: mirrored powers-of-three rows.
Homework1/Q3.java: a randomized factorial-weighted series. Negative N is rejected; zero is accepted. Non-integer input is not handled.
homework3 vehicle classes: constructors, position state, inheritance and overrides; entry point homework3.Test.
homework3 animal classes: inheritance, toString/greets overrides, greeting overload and an explicit downcast; entry point homework3.TestAnimalClasses.

A JDK is required. Package declarations and public class filenames are preserved. No .class files, IDE settings, supplied answer archives, exams or grades are included.
